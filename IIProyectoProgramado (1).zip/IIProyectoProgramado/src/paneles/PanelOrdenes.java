package paneles;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;

public class PanelOrdenes extends JPanel {

    private JTextField campoNumero, campoCliente, campoVehiculo, campoServicio, campoFechaIngreso, campoFechaEntrega, campoCosto;
    private DefaultTableModel modeloTabla;
    private JTable tablaOrdenes;
    private ArrayList<String> ordenes = new ArrayList<>();
    private final String archivo = "ordenes.csv";

    public PanelOrdenes() {
        setLayout(new BorderLayout());

        JPanel formulario = new JPanel(new GridLayout(8, 2, 5, 5));
        formulario.setBorder(BorderFactory.createTitledBorder("Datos de la Orden"));

        campoNumero = new JTextField();
        campoCliente = new JTextField();
        campoVehiculo = new JTextField();
        campoServicio = new JTextField();
        campoFechaIngreso = new JTextField();
        campoFechaEntrega = new JTextField();
        campoCosto = new JTextField();

        formulario.add(new JLabel("Número de Orden:"));
        formulario.add(campoNumero);
        formulario.add(new JLabel("Cliente:"));
        formulario.add(campoCliente);
        formulario.add(new JLabel("Vehículo:"));
        formulario.add(campoVehiculo);
        formulario.add(new JLabel("Servicio:"));
        formulario.add(campoServicio);
        formulario.add(new JLabel("Fecha de ingreso:"));
        formulario.add(campoFechaIngreso);
        formulario.add(new JLabel("Fecha de entrega:"));
        formulario.add(campoFechaEntrega);
        formulario.add(new JLabel("Costo total:"));
        formulario.add(campoCosto);

        JPanel botones = new JPanel(new FlowLayout());
        JButton btnRegistrar = new JButton("Registrar");
        JButton btnConsultar = new JButton("Consultar");
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");

        botones.add(btnRegistrar);
        botones.add(btnConsultar);
        botones.add(btnModificar);
        botones.add(btnEliminar);

        modeloTabla = new DefaultTableModel(
            new String[]{"Número", "Cliente", "Vehículo", "Servicio", "F. Ingreso", "F. Entrega", "Costo"}, 0);
        tablaOrdenes = new JTable(modeloTabla);
        JScrollPane scrollTabla = new JScrollPane(tablaOrdenes);

        JPanel centro = new JPanel(new BorderLayout());
        centro.add(formulario, BorderLayout.NORTH);
        centro.add(botones, BorderLayout.SOUTH);

        add(centro, BorderLayout.NORTH);
        add(scrollTabla, BorderLayout.CENTER);

        cargarOrdenes();
        actualizarTabla();

        btnRegistrar.addActionListener(e -> registrarOrden());
        btnConsultar.addActionListener(e -> consultarOrden());
        btnModificar.addActionListener(e -> modificarOrden());
        btnEliminar.addActionListener(e -> eliminarOrden());
    }

    private void registrarOrden() {
        String numero = campoNumero.getText().trim();
        String cliente = campoCliente.getText().trim();
        String vehiculo = campoVehiculo.getText().trim();
        String servicio = campoServicio.getText().trim();
        String fechaIngreso = campoFechaIngreso.getText().trim();
        String fechaEntrega = campoFechaEntrega.getText().trim();
        String costo = campoCosto.getText().trim();

        if (numero.isEmpty() || cliente.isEmpty() || vehiculo.isEmpty() || servicio.isEmpty()
                || fechaIngreso.isEmpty() || fechaEntrega.isEmpty() || costo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debes completar todos los campos para continuar");
            return;
        }

        for (String o : ordenes) {
            if (o.startsWith(numero + ",")) {
                JOptionPane.showMessageDialog(this, "Ya existe una orden con ese número");
                return;
            }
        }

        String orden = numero + "," + cliente + "," + vehiculo + "," + servicio + "," +
                       fechaIngreso + "," + fechaEntrega + "," + costo;
        ordenes.add(orden);
        guardarOrdenes();
        actualizarTabla();
        JOptionPane.showMessageDialog(this, "Orden registrada correctamente");
        limpiarCampos();
    }

    private void consultarOrden() {
        int fila = tablaOrdenes.getSelectedRow();
        if (fila != -1) {
            campoNumero.setText(modeloTabla.getValueAt(fila, 0).toString());
            campoCliente.setText(modeloTabla.getValueAt(fila, 1).toString());
            campoVehiculo.setText(modeloTabla.getValueAt(fila, 2).toString());
            campoServicio.setText(modeloTabla.getValueAt(fila, 3).toString());
            campoFechaIngreso.setText(modeloTabla.getValueAt(fila, 4).toString());
            campoFechaEntrega.setText(modeloTabla.getValueAt(fila, 5).toString());
            campoCosto.setText(modeloTabla.getValueAt(fila, 6).toString());
        } else {
            JOptionPane.showMessageDialog(this, "Selecciona una fila para consultar");
        }
    }

    private void modificarOrden() {
        String numero = campoNumero.getText().trim();
        for (int i = 0; i < ordenes.size(); i++) {
            String[] partes = ordenes.get(i).split(",");
            if (partes[0].equalsIgnoreCase(numero)) {
                String cliente = campoCliente.getText().trim();
                String vehiculo = campoVehiculo.getText().trim();
                String servicio = campoServicio.getText().trim();
                String fechaIngreso = campoFechaIngreso.getText().trim();
                String fechaEntrega = campoFechaEntrega.getText().trim();
                String costo = campoCosto.getText().trim();

                if (cliente.isEmpty() || vehiculo.isEmpty() || servicio.isEmpty() ||
                    fechaIngreso.isEmpty() || fechaEntrega.isEmpty() || costo.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Debes completar todos los campos");
                    return;
                }

                ordenes.set(i, numero + "," + cliente + "," + vehiculo + "," + servicio + "," +
                               fechaIngreso + "," + fechaEntrega + "," + costo);
                guardarOrdenes();
                actualizarTabla();
                JOptionPane.showMessageDialog(this, "Orden modificada correctamente");
                limpiarCampos();
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "Orden no encontrada");
    }

    private void eliminarOrden() {
        String numero = campoNumero.getText().trim();
        for (int i = 0; i < ordenes.size(); i++) {
            String[] partes = ordenes.get(i).split(",");
            if (partes[0].equalsIgnoreCase(numero)) {
                int confirm = JOptionPane.showConfirmDialog(this, "¿Eliminar esta orden?", "Confirmar", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    ordenes.remove(i);
                    guardarOrdenes();
                    actualizarTabla();
                    JOptionPane.showMessageDialog(this, "Orden eliminada correctamente");
                    limpiarCampos();
                }
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "Orden no encontrada");
    }

    private void actualizarTabla() {
        modeloTabla.setRowCount(0);
        for (String o : ordenes) {
            String[] partes = o.split(",");
            if (partes.length == 7) {
                modeloTabla.addRow(partes);
            }
        }
    }

    private void limpiarCampos() {
        campoNumero.setText("");
        campoCliente.setText("");
        campoVehiculo.setText("");
        campoServicio.setText("");
        campoFechaIngreso.setText("");
        campoFechaEntrega.setText("");
        campoCosto.setText("");
    }

    private void guardarOrdenes() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(archivo))) {
            for (String o : ordenes) {
                pw.println(o);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar las órdenes");
        }
    }

    private void cargarOrdenes() {
        ordenes.clear();
        File f = new File(archivo);
        if (!f.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 7) {
                    ordenes.add(linea);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar las órdenes");
        }
    }
}
