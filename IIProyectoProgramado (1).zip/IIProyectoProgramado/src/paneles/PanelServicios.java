package paneles;

import servicios.ControladorServicios;
import servicios.Servicio;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class PanelServicios extends JPanel {
    private ControladorServicios controladorServicios;

    private JTextField txtCodigo;
    private JTextField txtDescripcion;
    private JComboBox<String> comboTipo;
    private JTextField txtOrdenId;
    private JTextField txtCosto;
    private JTable tablaServicios;
    private DefaultTableModel modeloTabla;

    public PanelServicios() {
        controladorServicios = new ControladorServicios();
        setLayout(new BorderLayout());

        JPanel panelFormulario = new JPanel(new GridLayout(5, 2));
        panelFormulario.add(new JLabel("Código:"));
        txtCodigo = new JTextField();
        panelFormulario.add(txtCodigo);

        panelFormulario.add(new JLabel("Descripción:"));
        txtDescripcion = new JTextField();
        panelFormulario.add(txtDescripcion);

        panelFormulario.add(new JLabel("Tipo:"));
        comboTipo = new JComboBox<>(new String[]{"Mecánica", "Pintura", "Revisión", "Otros"});
        panelFormulario.add(comboTipo);

        panelFormulario.add(new JLabel("ID Orden Trabajo:"));
        txtOrdenId = new JTextField();
        panelFormulario.add(txtOrdenId);

        panelFormulario.add(new JLabel("Costo:"));
        txtCosto = new JTextField();
        panelFormulario.add(txtCosto);

        add(panelFormulario, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new Object[]{"Código", "Descripción", "Tipo", "Orden ID", "Costo"}, 0);
        tablaServicios = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaServicios);
        add(scrollPane, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new GridLayout(2, 2, 10, 10));
        JButton btnRegistrar = new JButton("Registrar");
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnConsultar = new JButton("Consultar");

        panelBotones.add(btnRegistrar);
        panelBotones.add(btnModificar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnConsultar);

        add(panelBotones, BorderLayout.SOUTH);

        // Evento Registrar
        btnRegistrar.addActionListener(e -> {
            String codigo = txtCodigo.getText();
            String descripcion = txtDescripcion.getText();
            String tipo = (String) comboTipo.getSelectedItem();
            String ordenId = txtOrdenId.getText();
            double costo = Double.parseDouble(txtCosto.getText());

            Servicio nuevoServicio = new Servicio(codigo, descripcion, tipo, ordenId, costo);
            if (controladorServicios.agregarServicio(nuevoServicio)) {
                JOptionPane.showMessageDialog(this, "Servicio registrado");
                actualizarTabla();
            } else {
                JOptionPane.showMessageDialog(this, "El servicio ya existe");
            }
        });

        // Evento Consultar
        btnConsultar.addActionListener(e -> actualizarTabla());

        // Evento Eliminar
        btnEliminar.addActionListener(e -> {
            String codigo = txtCodigo.getText();
            if (controladorServicios.eliminarServicio(codigo)) {
                JOptionPane.showMessageDialog(this, "Servicio eliminado");
                actualizarTabla();
            } else {
                JOptionPane.showMessageDialog(this, "Servicio no encontrado");
            }
        });

        // Evento Modificar
        btnModificar.addActionListener(e -> {
            String codigo = txtCodigo.getText();
            String descripcion = txtDescripcion.getText();
            String tipo = (String) comboTipo.getSelectedItem();
            String ordenId = txtOrdenId.getText();
            double costo = Double.parseDouble(txtCosto.getText());

            Servicio actualizado = new Servicio(codigo, descripcion, tipo, ordenId, costo);
            controladorServicios.modificarServicio(codigo, actualizado);
            JOptionPane.showMessageDialog(this, "Servicio modificado correctamente");
            actualizarTabla();
        });

        actualizarTabla();
    }

    private void actualizarTabla() {
        modeloTabla.setRowCount(0);
        for (Servicio s : controladorServicios.getListaServicios()) {
            modeloTabla.addRow(new Object[]{
                s.getCodigo(), s.getDescripcion(), s.getTipo(), s.getIdOrdenTrabajo(), s.getCosto()
            });
        }
    }
}
