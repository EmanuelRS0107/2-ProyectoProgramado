package persistencia;

import clientes.ClassCliente;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class GestionadorDeArchivos {

    private String ruta;

    public GestionadorDeArchivos(String ruta) {
        this.ruta = ruta;
    }

    // Leer archivo línea por línea
    public ArrayList<String> leerArchivo() {
        ArrayList<String> lineas = new ArrayList<>();
        File archivo = new File(ruta);

        if (!archivo.exists()) {
            // Si el archivo no existe, lo crea vacío
            try {
                archivo.createNewFile();
            } catch (IOException e) {
                System.out.println("No se pudo crear el archivo: " + ruta);
            }
            return lineas;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                lineas.add(linea);
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + ruta);
        }

        return lineas;
    }

    // Agregar una línea al final del archivo
    public void escribirLinea(String linea) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta, true))) {
            bw.write(linea);
            bw.newLine();
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo: " + ruta);
        }
    }

    //Sobrescribir todo el archivo con nuevas líneas
    public void sobrescribirArchivo(ArrayList<String> lineas) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            for (String linea : lineas) {
                bw.write(linea);
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error al sobrescribir el archivo: " + ruta);
        }
    }

    //Guarda lista de clientes en archivo
    public static void guardarClientes(List<ClassCliente> lista) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("clientes.txt"))) {
            for (ClassCliente cliente : lista) {
                String linea = cliente.getCedula() + "," + cliente.getNombre() + "," + cliente.getTelefono() + "," + cliente.getDireccion();
                bw.write(linea);
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error al guardar clientes.");
        }
    }

    //Carga lista de clientes desde archivo
    public static List<ClassCliente> cargarClientes() {
        List<ClassCliente> lista = new ArrayList<>();
        File archivo = new File("clientes.txt");

        if (!archivo.exists()) {
            return lista; // Devuelve lista vacía si no existe el archivo
        }

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 4) {
                    String cedula = partes[0];
                    String nombre = partes[1];
                    String telefono = partes[2];
                    String direccion = partes[3];
                    ClassCliente cliente = new ClassCliente(cedula, nombre, telefono, direccion);
                    lista.add(cliente);
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar clientes.");
        }

        return lista;
    }
}

