package iiproyectoprogramado;

public class VehiculoTaller {
    private String placa;
    private String marca;
    private String modelo;
    private String color;

    public VehiculoTaller(String placa, String marca, String modelo, String color) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    public String getPlaca() {
        return placa;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public String[] toArray() {
        return new String[] { placa, marca, modelo, color };
    }
}
