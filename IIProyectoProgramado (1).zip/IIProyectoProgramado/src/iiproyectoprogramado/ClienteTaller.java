package iiproyectoprogramado;

public class ClienteTaller {
    private String nombre;
    private String cedula;

    public ClienteTaller(String nombre, String cedula) {
        this.nombre = nombre;
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCedula() {
        return cedula;
    }
}
