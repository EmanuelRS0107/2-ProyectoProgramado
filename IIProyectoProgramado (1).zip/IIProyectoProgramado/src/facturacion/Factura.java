package facturacion;

public interface Factura {
    double calcularCosto();
}
