package clientes;

import java.util.Scanner;

public class ConsolaClientes {

    private ControladorCliente controladorCliente;
    private Scanner scanner;

    public ConsolaClientes() {
        controladorCliente = new ControladorCliente();
        scanner = new Scanner(System.in);
    }

    public void mostrarMenu() {
        int opcion;
        do {
            System.out.println("\n--- Gestión de Clientes ---");
            System.out.println("1. Registrar cliente");
            System.out.println("2. Consultar clientes");
            System.out.println("3. Modificar cliente");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1 -> registrarCliente();
                case 2 -> consultarClientes();
                case 3 -> modificarCliente();
                case 0 -> System.out.println("Volviendo...");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 0);
    }

    private void registrarCliente() {
        System.out.println("Ingrese cédula:");
        String cedula = scanner.nextLine();
        System.out.println("Ingrese nombre:");
        String nombre = scanner.nextLine();
        System.out.println("Ingrese teléfono:");
        String telefono = scanner.nextLine();
        System.out.println("Ingrese dirección:");
        String direccion = scanner.nextLine();

        ClassCliente nuevoCliente = new ClassCliente(cedula, nombre, telefono, direccion);
        controladorCliente.registrarCliente(nuevoCliente);
        System.out.println("Cliente registrado correctamente.");
    }

    private void consultarClientes() {
        System.out.println("\n--- Lista de Clientes ---");
        for (ClassCliente cliente : controladorCliente.getListaClientes()) {
            System.out.println(cliente);
        }
    }

    private void modificarCliente() {
        System.out.println("Ingrese la cédula del cliente a modificar:");
        String cedula = scanner.nextLine();
        ClassCliente cliente = controladorCliente.buscarClientePorCedula(cedula);
        if (cliente != null) {
            System.out.println("Ingrese nuevo nombre:");
            String nombre = scanner.nextLine();
            System.out.println("Ingrese nuevo teléfono:");
            String telefono = scanner.nextLine();
            System.out.println("Ingrese nueva dirección:");
            String direccion = scanner.nextLine();

            controladorCliente.modificarCliente(cedula, nombre, telefono, direccion);
            System.out.println("Cliente modificado exitosamente.");
        } else {
            System.out.println("Cliente no encontrado.");
        }
    }
}
